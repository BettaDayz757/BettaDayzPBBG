const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, index: true, unique: true },
  passwordHash: { type: String, required: true },
  roles: { type: [String], default: ['player'] },
  createdAt: { type: Date, default: Date.now },
  lastLoginAt: { type: Date },
  settings: {
    locale: { type: String, default: 'en' },
    communications: {
      newsletter: { type: Boolean, default: true },
      productUpdates: { type: Boolean, default: false }
    }
  },
  // Each user can create multiple characters
  characters: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Character' }]
});

module.exports = mongoose.model('User', UserSchema);
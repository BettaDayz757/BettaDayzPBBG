import React, { useState } from 'react';

/**
 * Starter AvatarEditor component
 * - Keeps avatar state locally and sends updates to server when saved.
 * - In production, break into smaller components (hair, skin, clothes, accessories).
 */

export default function AvatarEditor({ avatar = {}, onSave }) {
  const [local, setLocal] = useState({
    skinTone: avatar.skinTone || '#b6865f',
    hairStyle: avatar.hairStyle || 'short',
    hairColor: avatar.hairColor || '#2b1b0a',
    outfit: avatar.outfit || 'casual',
    accessory: avatar.accessory || null
  });

  function update(field, value) {
    setLocal(prev => ({ ...prev, [field]: value }));
  }

  async function handleSave() {
    // send to parent or API
    if (onSave) onSave(local);
    // fallback example: await fetch('/api/characters/:id/avatar', {method:'PATCH', body: JSON.stringify(local)})
  }

  return (
    <div className="avatar-editor">
      <h3>Avatar Editor</h3>
      <label>Skin Tone</label>
      <input type="color" value={local.skinTone} onChange={e => update('skinTone', e.target.value)} />
      <label>Hair Style</label>
      <select value={local.hairStyle} onChange={e => update('hairStyle', e.target.value)}>
        <option value="short">Short</option>
        <option value="curly">Curly</option>
        <option value="braids">Braids</option>
        <option value="bun">Bun</option>
      </select>
      <label>Hair Color</label>
      <input type="color" value={local.hairColor} onChange={e => update('hairColor', e.target.value)} />
      <label>Outfit</label>
      <select value={local.outfit} onChange={e => update('outfit', e.target.value)}>
        <option value="casual">Casual</option>
        <option value="street">Street</option>
        <option value="formal">Formal</option>
      </select>
      <label>Accessory</label>
      <select value={local.accessory || ''} onChange={e => update('accessory', e.target.value || null)}>
        <option value="">None</option>
        <option value="sunglasses">Sunglasses</option>
        <option value="chain">Chain</option>
      </select>

      <div style={{ marginTop: 12 }}>
        <button onClick={handleSave}>Save Avatar</button>
      </div>
    </div>
  );
}
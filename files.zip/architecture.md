# BettaDayz Architecture Overview

Components
- Frontend (React):
  - Pages: Landing, Dashboard, Character, Neighborhood Map, House, Marketplace, Crew, Chat.
  - Components: AvatarEditor, Inventory, JobPanel, MissionPanel, HouseEditor, Shop.
  - State: auth, character, wallet, inventory, realtime events (via sockets).

- Backend (Node + Express):
  - REST endpoints for CRUD and actions.
  - Socket.IO for chat, live events, marketplace auctions.
  - Job queue (BullMQ) for scheduled ticks, aging, long-running missions.

- Database:
  - MongoDB for persistent data.
  - Redis for sessions, cooldowns, and Pub/Sub.

Key flows
- Character creation -> server creates character doc and initial items, queues daily ticks.
- Action (job/mission/crime) -> client POST -> server validates, checks cooldown, resolves and returns result + transaction record.
- Marketplace listing -> item posted in DB, websockets notify watchers.

Scaling
- Stateless Node servers behind a load balancer.
- Redis adapter for Socket.IO to scale across nodes.
- Use CDN for static assets.

Security
- Validate all server-side (never trust the client).
- Keep monetary transaction flows server-authoritative.
- Audit logs for trades, purchases, and admin actions.

Cultural & content workflow
- Content store for artists & creators with metadata and approvals.
- Community moderation pipeline with reporting and human review.
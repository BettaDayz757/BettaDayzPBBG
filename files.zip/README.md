# BettaDayz — PBBG (Merged MERN Template)

A Persistent Browser-Based Game that blends life simulation (BitLife), crime/economy (Torn.com), and social/avatar customization (IMVU). The setting is Norfolk, VA with minority / African American inspired themes and community-focused design.

Overview
- Stack: MERN (MongoDB, Express, React, Node), Socket.IO for realtime.
- Goals: Create an engaging life sim + social economy where players make choices, own property, join crews, and customize avatars.
- Design principles: Community-centred, culturally respectful, accessible, fair economy (cosmetic monetization).

Getting started (local)
1. Clone the repository and set up environment variables:
   - MONGO_URI, JWT_SECRET, REDIS_URL, S3_BUCKET (if used)
2. Install dependencies (recommended: pnpm or yarn workspaces).
3. Start dev servers:
   - Backend: `npm run dev --workspace=server`
   - Frontend: `npm run dev --workspace=app`

Roadmap
- Phase 1: Auth, characters, avatar customization, jobs, marketplace, simple crimes, neighborhoods, chat.
- Phase 2: Housing, crews, events, seasonal content.
- Phase 3: Richer avatar systems, UGC, mobile optimization, monetization.

Contributing
- Open issues for feature requests and bugs.
- Follow the code of conduct and be respectful in all community interactions.
- Engage with community members for content accuracy and cultural guidance.

License
- Add your preferred license (MIT recommended for templates).
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
// placeholder models
const Character = require('../models/Character');
const Mission = require('../models/Mission');
const { requireAuth } = require('../middleware/auth');

// POST /api/game/missions/:id/do
// Attempt a mission/crime. Server must validate cooldowns and perform reward/risk resolution.
router.post('/missions/:id/do', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const missionId = req.params.id;
    const charId = req.body.characterId;

    const character = await Character.findOne({ _id: charId, owner: userId });
    if (!character) return res.status(404).json({ error: 'Character not found' });

    const mission = await Mission.findById(missionId);
    if (!mission) return res.status(404).json({ error: 'Mission not found' });

    // check cooldowns (example)
    if (character.cooldowns && character.cooldowns.missions && character.cooldowns.missions[missionId]) {
      return res.status(429).json({ error: 'Mission on cooldown' });
    }

    // Risk calc: combine character stats + mission risk + randomness
    const skill = character.stats.streetSmart || 0;
    const baseSuccess = mission.baseSuccess || 0.5;
    const successChance = Math.min(0.95, baseSuccess + skill * 0.01);

    const roll = Math.random();
    let result = {};
    if (roll <= successChance) {
      // success
      character.wallet += mission.rewardMoney;
      character.reputation = (character.reputation || 0) + mission.successRep || 1;
      result = { success: true, reward: mission.rewardMoney, rep: mission.successRep || 1 };
    } else {
      // failure consequences
      character.health = (character.health || 100) - (mission.failureHealthLoss || 10);
      character.reputation = (character.reputation || 0) - (mission.failureRepLoss || 1);
      result = { success: false, healthLoss: mission.failureHealthLoss || 10, repLoss: mission.failureRepLoss || 1 };
    }

    // set cooldown example
    character.cooldowns = character.cooldowns || {};
    character.cooldowns.missions = character.cooldowns.missions || {};
    character.cooldowns.missions[missionId] = Date.now() + (mission.cooldownMs || 60000);

    await character.save();

    // Optional: emit socket event to neighborhood / followers
    // req.io.to(`neighborhood_${character.neighborhood}`).emit('missionResult', { characterId: charId, result });

    return res.json({ characterId: charId, missionId, ...result });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
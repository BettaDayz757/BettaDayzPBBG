globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cedd0592._.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_9212ccad._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_1dd7fb59.js",
    "static/chunks/node_modules_next_dist_compiled_a0e4c7b4._.js",
    "static/chunks/node_modules_next_dist_client_a38d7d69._.js",
    "static/chunks/node_modules_next_dist_4b2403f5._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_d80fb378._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_86f4650b._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];
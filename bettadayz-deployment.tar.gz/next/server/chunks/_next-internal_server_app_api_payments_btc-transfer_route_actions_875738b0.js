module.exports=[27178,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_payments_btc-transfer_route_actions_875738b0.js.map
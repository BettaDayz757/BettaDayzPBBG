var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/guilds/route.js")
R.c("server/chunks/[root-of-the-server]__29d90658._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__49f65a39._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_guilds_route_actions_c4c1b1df.js")
R.m(99373)
module.exports=R.m(99373).exports

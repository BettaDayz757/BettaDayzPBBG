var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/bitcoin/route.js")
R.c("server/chunks/[root-of-the-server]__464a4d9a._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__49f65a39._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/[root-of-the-server]__0d39343c._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_bitcoin_route_actions_98ebb999.js")
R.m(47306)
module.exports=R.m(47306).exports

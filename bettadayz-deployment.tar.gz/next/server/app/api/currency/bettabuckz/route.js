var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/currency/bettabuckz/route.js")
R.c("server/chunks/[root-of-the-server]__d806fd51._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__49f65a39._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_currency_bettabuckz_route_actions_5b4fa316.js")
R.m(22651)
module.exports=R.m(22651).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tournaments/route.js")
R.c("server/chunks/[root-of-the-server]__634cc029._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__49f65a39._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_tournaments_route_actions_7e5fea26.js")
R.m(73858)
module.exports=R.m(73858).exports

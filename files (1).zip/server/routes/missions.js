const express = require('express');
const router = express.Router();

const Character = require('../models/Character');
const Mission = require('../models/Mission');

// NOTE: This file assumes authentication middleware attaches req.user with { id }
// Replace requireAuth with your real auth middleware when integrating.
const requireAuth = (req, res, next) => {
  // for scaffold dev, optionally accept ?userId=... as shortcut
  if (req.query.userId) {
    req.user = { id: req.query.userId };
    return next();
  }
  return res.status(401).json({ error: 'Authentication required (scaffold).' });
};

// POST /api/missions/:id/do
router.post('/:id/do', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const missionId = req.params.id;
    const charId = req.body.characterId;

    const character = await Character.findOne({ _id: charId, owner: userId });
    if (!character) return res.status(404).json({ error: 'Character not found' });

    const mission = await Mission.findById(missionId);
    if (!mission) return res.status(404).json({ error: 'Mission not found' });

    // cooldown check
    character.cooldowns = character.cooldowns || {};
    character.cooldowns.missions = character.cooldowns.missions || {};
    const cd = character.cooldowns.missions[missionId];
    if (cd && cd > Date.now()) {
      return res.status(429).json({ error: 'Mission on cooldown', retryAt: cd });
    }

    // success calculation
    const skill = character.stats.streetSmart || 0;
    const successChance = Math.min(0.95, mission.baseSuccess + skill * 0.01);
    const roll = Math.random();

    let result = {};
    if (roll <= successChance) {
      character.wallet += mission.rewardMoney;
      character.stats.reputation = (character.stats.reputation || 0) + mission.successRep;
      result = { success: true, reward: mission.rewardMoney, rep: mission.successRep };
    } else {
      character.stats.health = Math.max(0, (character.stats.health || 100) - mission.failureHealthLoss);
      character.stats.reputation = (character.stats.reputation || 0) - mission.failureRepLoss;
      result = { success: false, healthLoss: mission.failureHealthLoss, repLoss: mission.failureRepLoss };
    }

    // set cooldown
    character.cooldowns.missions[missionId] = Date.now() + (mission.cooldownMs || 60000);
    await character.save();

    // emit event to neighborhood room for social visibility
    if (req.io && character.neighborhood) {
      req.io.to(`neighborhood_${character.neighborhood}`).emit('missionResult', {
        characterId: charId,
        missionId,
        result
      });
    }

    return res.json({ characterId: charId, missionId, result });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
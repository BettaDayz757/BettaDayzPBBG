const path = require('path');
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const cors = require('cors');
const { Server } = require('socket.io');
require('dotenv').config();

const missionsRoute = require('./routes/missions');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// simple middleware to attach io to request if needed
app.use((req, res, next) => {
  req.io = io;
  next();
});

app.use(express.json());
app.use(cors());

// Routes
app.use('/api/missions', missionsRoute);

// Health
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Connect Mongo
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/bettadayz';
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Mongo connected'))
  .catch(err => console.error('Mongo connection error', err));

// Socket handling
io.on('connection', (socket) => {
  console.log('socket connected', socket.id);

  socket.on('joinRoom', (room) => {
    socket.join(room);
  });

  socket.on('disconnect', () => {
    // handle disconnect
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Server listening on ${PORT}`));
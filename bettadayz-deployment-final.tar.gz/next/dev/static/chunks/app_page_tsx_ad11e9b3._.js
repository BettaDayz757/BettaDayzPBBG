(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_ebbd8575.js",
  "static/chunks/_f0e0aac1._.js",
  "static/chunks/node_modules_de0fc18e._.js"
],
    source: "dynamic"
});
